import 'package:flutter/material.dart';
import 'package:flutter_application_1/models/parkir.dart';

class ParkirTile extends StatelessWidget {
  final Parkir parkir;
  void Function()? onPressed;
  final Widget icon;
  ParkirTile({
    super.key, 
    required this.parkir, 
    required this.onPressed, 
    required this.icon,
    });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(color: Colors.grey[200],
      borderRadius: BorderRadius.circular(12)),
      margin: EdgeInsets.only(bottom: 10),
      padding: EdgeInsets.symmetric(vertical: 25,horizontal: 10),
      child: ListTile(
      title: Text(parkir.name),
      subtitle: Text(parkir.price),
      leading: Image.asset(parkir.imagePath),
      trailing: IconButton(
        icon: icon,
        onPressed: onPressed,
      ),
    ),
    );
  }
} 