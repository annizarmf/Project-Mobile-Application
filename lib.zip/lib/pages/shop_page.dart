import 'package:flutter/material.dart';
import 'package:flutter_application_1/components/parkir_tile.dart';
import 'package:flutter_application_1/models/parkir.dart';
import 'package:provider/provider.dart';
import 'package:flutter_application_1/models/parkir_shop.dart';

class ShopPage extends StatefulWidget {
  const ShopPage({super.key});

  @override
  State<ShopPage> createState() => _ShopPageState();
}

class _ShopPageState extends State<ShopPage> {

  //add parkir to cart
  void addToCart(Parkir parkir){
    Provider.of<ParkirShop>(context, listen: false).addItemToCart(parkir);
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<ParkirShop>(
      builder: (context, value, child) => SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(25.0),
        child: Column(children: [
          //heading
          const Text(
            "Mau Parkir Dimana?",
            style: TextStyle(fontSize: 20),
            ),
            const SizedBox(height: 25,),

            //list of parkiran
            Expanded(
              child: ListView.builder(
                itemCount: value.parkirShop.length,
                itemBuilder: (context, index){
                //get individual parkiran
                Parkir eachParkir = value.parkirShop[index];

                //return the tile for this parkir
                return ParkirTile(
                  parkir: eachParkir,
                  icon: Icon(Icons.add),
                  onPressed: () => addToCart(eachParkir),
                );
              }))
        ]
      ),
      ),
    ),
  );
  }
}