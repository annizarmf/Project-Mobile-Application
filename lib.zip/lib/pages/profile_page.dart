import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  void _navigateTo(BuildContext context, String page) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) {
        switch (page) {
          case 'Membership':
            return MembershipPage();
          case 'Points':
            return PointsPage();
          case 'Wallet':
            return WalletPage();
          case 'PayOnStreet':
            return PayOnStreetPage();
          default:
            return ProfilePage();
        }
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profile'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            _buildProfileOption(
              context,
              icon: Icons.card_membership,
              title: 'Membership',
              description: 'View your membership details',
              onTap: () => _navigateTo(context, 'Membership'),
            ),
            SizedBox(height: 16),
            _buildProfileOption(
              context,
              icon: Icons.star,
              title: 'Points',
              description: 'Check your points balance',
              onTap: () => _navigateTo(context, 'Points'),
            ),
            SizedBox(height: 16),
            _buildProfileOption(
              context,
              icon: Icons.account_balance_wallet,
              title: 'Wallet',
              description: 'Manage your wallet',
              onTap: () => _navigateTo(context, 'Wallet'),
            ),
            SizedBox(height: 16),
            _buildProfileOption(
              context,
              icon: Icons.directions_car,
              title: 'Pay On Street',
              description: 'Pay for street parking',
              onTap: () => _navigateTo(context, 'PayOnStreet'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileOption(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String description,
    required void Function()? onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.2),
              spreadRadius: 2,
              blurRadius: 5,
              offset: Offset(0, 3), // changes position of shadow
            ),
          ],
        ),
        child: Row(
          children: [
            Icon(icon, size: 40, color: Colors.blue),
            SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    description,
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey[600],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Dummy pages for Membership, Points, and Wallet
class MembershipPage extends StatefulWidget {
  @override
  _MembershipPageState createState() => _MembershipPageState();
}

class _MembershipPageState extends State<MembershipPage> {
  TextEditingController locationController = TextEditingController();
  TextEditingController plateController = TextEditingController();
  List<Membership> memberships = [];

  @override
  void initState() {
    super.initState();
    fetchMemberships();
  }

  Future<void> fetchMemberships() async {
    var url = Uri.parse('https://nizar.sihorizonu.com//membership_api/get_membership.php');
    var response = await http.get(url);

    if (response.statusCode == 200) {
      List<dynamic> data = jsonDecode(response.body);
      setState(() {
        memberships = data.map((item) => Membership.fromJson(item)).toList();
      });
    } else {
      print('Failed to load memberships: ${response.reasonPhrase}');
    }
  }

  Future<void> createMembership(String location, String plateNumber) async {
    var url = Uri.parse('https://nizar.sihorizonu.com/membership_api/create_membership.php');
    var response = await http.post(url, body: {
      'location': location,
      'plate_number': plateNumber,
    });

    if (response.statusCode == 200) {
      print('Membership created successfully');
      fetchMemberships(); // Refresh membership list
    } else {
      print('Failed to create membership: ${response.reasonPhrase}');
    }
  }

  Future<void> updateMembership(int id, String location, String plateNumber) async {
    var url = Uri.parse('https://nizar.sihorizonu.com/membership_api/update_membership.php');
    var response = await http.post(url, body: {
      'id': id.toString(),
      'location': location,
      'plate_number': plateNumber,
    });

    if (response.statusCode == 200) {
      print('Membership updated successfully');
      fetchMemberships(); // Refresh membership list
    } else {
      print('Failed to update membership: ${response.reasonPhrase}');
    }
  }

  Future<void> deleteMembership(int id) async {
    var url = Uri.parse('https://nizar.sihorizonu.com/membership_api/delete_membership.php');
    var response = await http.post(url, body: {
      'id': id.toString(),
    });

    if (response.statusCode == 200) {
      print('Membership deleted successfully');
      fetchMemberships(); // Refresh membership list
    } else {
      print('Failed to delete membership: ${response.reasonPhrase}');
    }
  }

  void showEditDialog(Membership membership) {
    locationController.text = membership.location;
    plateController.text = membership.plateNumber;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Edit Membership'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: locationController,
                decoration: InputDecoration(labelText: 'Location'),
              ),
              TextField(
                controller: plateController,
                decoration: InputDecoration(labelText: 'Plate Number'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                updateMembership(
                  membership.id,
                  locationController.text,
                  plateController.text,
                );
                Navigator.of(context).pop();
                locationController.clear();
                plateController.clear();
              },
              child: Text('Update'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Membership System'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Register/Search Membership Here',
              style: TextStyle(
                fontSize: 24.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 16.0),
            TextField(
              controller: locationController,
              decoration: InputDecoration(
                labelText: 'Location Name',
                border: OutlineInputBorder(),
                hintText: 'Enter location name',
              ),
            ),
            SizedBox(height: 16.0),
            TextField(
              controller: plateController,
              decoration: InputDecoration(
                labelText: 'Plate Number',
                border: OutlineInputBorder(),
                hintText: 'Enter plate number',
              ),
            ),
            SizedBox(height: 16.0),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  // Add search functionality here
                },
                child: Text('Search'),
              ),
            ),
            SizedBox(height: 16.0),
            Expanded(
              child: ListView.builder(
                itemCount: memberships.length,
                itemBuilder: (context, index) {
                  return Card(
                    margin: EdgeInsets.symmetric(vertical: 8.0),
                    child: ListTile(
                      title: Text(memberships[index].location),
                      subtitle: Text('Plate Number: ${memberships[index].plateNumber}'),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: Icon(Icons.edit),
                            onPressed: () {
                              showEditDialog(memberships[index]);
                            },
                          ),
                          IconButton(
                            icon: Icon(Icons.delete),
                            onPressed: () {
                              deleteMembership(memberships[index].id);
                            },
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          locationController.clear();
          plateController.clear();
          showDialog(
            context: context,
            builder: (BuildContext context) {
              return AlertDialog(
                title: Text('Create Membership'),
                content: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: locationController,
                      decoration: InputDecoration(labelText: 'Location'),
                    ),
                    TextField(
                      controller: plateController,
                      decoration: InputDecoration(labelText: 'Plate Number'),
                    ),
                  ],
                ),
                actions: [
                  TextButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    child: Text('Cancel'),
                  ),
                  TextButton(
                    onPressed: () {
                      createMembership(
                        locationController.text,
                        plateController.text,
                      );
                      Navigator.of(context).pop();
                      locationController.clear();
                      plateController.clear();
                    },
                    child: Text('Create'),
                  ),
                ],
              );
            },
          );
        },
        child: Icon(Icons.add),
      ),
    );
  }
}

class Membership {
  final int id;
  final String location;
  final String plateNumber;

  Membership({required this.id, required this.location, required this.plateNumber});

  factory Membership.fromJson(Map<String, dynamic> json) {
    return Membership(
      id: int.parse(json['id']),
      location: json['location'],
      plateNumber: json['plate_number'],
    );
  }
}

class PointsPage extends StatelessWidget {
   @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Points'),
        centerTitle: true,
        backgroundColor: Colors.blue,
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.wallet_giftcard),
            label: 'Wallet',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.qr_code_scanner),
            label: 'Pay',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.account_circle),
            label: 'Account',
          ),
        ],
        selectedItemColor: Colors.blue,
        unselectedItemColor: Colors.grey,
        showUnselectedLabels: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                color: Colors.amber,
                borderRadius: BorderRadius.circular(8.0),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Poin Anda : 0',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 8.0),
                  Text(
                    'Status : Gold',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
            SizedBox(height: 8.0),
            Text(
              'Poin anda akan hangus pada : 31 Desember 2023',
              style: TextStyle(fontSize: 14, color: Colors.red),
            ),
            SizedBox(height: 16.0),
            Text(
              'Your Reward',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 16.0),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                RewardCard(
                  points: 8000,
                  description: 'Disc. 25% Parking Fee',
                  expiryDate: '31 Des 2023',
                ),
                RewardCard(
                  points: 5000,
                  description: 'Free Aqua 350ml',
                  expiryDate: '31 Des 2023',
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class RewardCard extends StatelessWidget {
  final int points;
  final String description;
  final String expiryDate;

  RewardCard({
    required this.points,
    required this.description,
    required this.expiryDate,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 150,
      padding: EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: Colors.blue,
        borderRadius: BorderRadius.circular(8.0),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
            decoration: BoxDecoration(
              color: Colors.yellow,
              borderRadius: BorderRadius.circular(4.0),
            ),
            child: Text(
              'PROMO',
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
            ),
          ),
          SizedBox(height: 8.0),
          Text(
            '$points Poin',
            style: TextStyle(
                fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
          ),
          SizedBox(height: 8.0),
          Text(
            description,
            style: TextStyle(fontSize: 14, color: Colors.white),
          ),
          SizedBox(height: 8.0),
          Text(
            'Until : $expiryDate',
            style: TextStyle(fontSize: 12, color: Colors.white),
          ),
        ],
      ),
    );
  }
}

class WalletPage extends StatefulWidget {
  @override
  _WalletPageState createState() => _WalletPageState();
}

class _WalletPageState extends State<WalletPage> {
  TextEditingController nameController = TextEditingController();
  TextEditingController balanceController = TextEditingController();
  List<Wallet> wallets = [];

  @override
  void initState() {
    super.initState();
    fetchWallets();
  }

  Future<void> fetchWallets() async {
    var url = Uri.parse('https://nizar.sihorizonu.com/wallet_api/get_wallets.php');
    var response = await http.get(url);

    if (response.statusCode == 200) {
      try {
        List<dynamic> data = jsonDecode(response.body);
        setState(() {
          wallets = data.map((item) => Wallet.fromJson(item)).toList();
        });
      } catch (e) {
        print('Error parsing JSON: $e');
      }
    } else {
      print('Failed to load wallets: ${response.reasonPhrase}');
    }
  }

  Future<void> createWallet(String name, double balance) async {
    var url = Uri.parse('https://nizar.sihorizonu.com/wallet_api/create_wallet.php');
    var response = await http.post(url, body: {
      'name': name,
      'balance': balance.toString(),
    });

    if (response.statusCode == 200) {
      try {
        var responseBody = jsonDecode(response.body);
        if (responseBody['success'] != null) {
          print('Wallet created successfully');
          fetchWallets(); // Refresh wallet list
        } else {
          print('Failed to create wallet: ${responseBody['error']}');
        }
      } catch (e) {
        print('Error parsing JSON: $e');
      }
    } else {
      print('Failed to create wallet: ${response.reasonPhrase}');
    }
  }

  Future<void> updateWallet(int id, String name, double balance) async {
    var url = Uri.parse('https://nizar.sihorizonu.com/wallet_api/update_wallet.php');
    var response = await http.post(url, body: {
      'id': id.toString(),
      'name': name,
      'balance': balance.toString(),
    });

    if (response.statusCode == 200) {
      try {
        var responseBody = jsonDecode(response.body);
        if (responseBody['success'] != null) {
          print('Wallet updated successfully');
          fetchWallets(); // Refresh wallet list
        } else {
          print('Failed to update wallet: ${responseBody['error']}');
        }
      } catch (e) {
        print('Error parsing JSON: $e');
      }
    } else {
      print('Failed to update wallet: ${response.reasonPhrase}');
    }
  }

  Future<void> deleteWallet(int id) async {
    var url = Uri.parse('https://nizar.sihorizonu.com/wallet_api/delete_wallet.php');
    var response = await http.post(url, body: {
      'id': id.toString(),
    });

    if (response.statusCode == 200) {
      try {
        var responseBody = jsonDecode(response.body);
        if (responseBody['success'] != null) {
          print('Wallet deleted successfully');
          fetchWallets(); // Refresh wallet list
        } else {
          print('Failed to delete wallet: ${responseBody['error']}');
        }
      } catch (e) {
        print('Error parsing JSON: $e');
      }
    } else {
      print('Failed to delete wallet: ${response.reasonPhrase}');
    }
  }

  void showEditDialog(Wallet wallet) {
    nameController.text = wallet.name;
    balanceController.text = wallet.balance.toString();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Edit Wallet'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                decoration: InputDecoration(labelText: 'Name'),
              ),
              TextField(
                controller: balanceController,
                decoration: InputDecoration(labelText: 'Balance'),
                keyboardType: TextInputType.number,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                updateWallet(
                  wallet.id,
                  nameController.text,
                  double.parse(balanceController.text),
                );
                Navigator.of(context).pop();
                nameController.clear();
                balanceController.clear();
              },
              child: Text('Update'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Wallets'),
      ),
      body: ListView.builder(
        itemCount: wallets.length,
        itemBuilder: (context, index) {
          return Card(
            margin: EdgeInsets.all(10),
            child: ListTile(
              contentPadding: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
              leading: CircleAvatar(
                child: Text(wallets[index].name[0]),
              ),
              title: Text(
                wallets[index].name,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text('Balance: \$${wallets[index].balance.toStringAsFixed(2)}'),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: Icon(Icons.edit),
                    onPressed: () {
                      showEditDialog(wallets[index]);
                    },
                  ),
                  IconButton(
                    icon: Icon(Icons.delete),
                    onPressed: () {
                      deleteWallet(wallets[index].id);
                    },
                  ),
                ],
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          showDialog(
            context: context,
            builder: (BuildContext context) {
              return AlertDialog(
                title: Text('Create Wallet'),
                content: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: nameController,
                      decoration: InputDecoration(labelText: 'Name'),
                    ),
                    TextField(
                      controller: balanceController,
                      decoration: InputDecoration(labelText: 'Balance'),
                      keyboardType: TextInputType.number,
                    ),
                  ],
                ),
                actions: [
                  TextButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    child: Text('Cancel'),
                  ),
                  TextButton(
                    onPressed: () {
                      createWallet(
                        nameController.text,
                        double.parse(balanceController.text),
                      );
                      Navigator.of(context).pop();
                      nameController.clear();
                      balanceController.clear();
                    },
                    child: Text('Create'),
                  ),
                ],
              );
            },
          );
        },
        child: Icon(Icons.add),
      ),
    );
  }
}

class Wallet {
  final int id;
  final String name;
  final double balance;

  Wallet({required this.id, required this.name, required this.balance});

  factory Wallet.fromJson(Map<String, dynamic> json) {
    return Wallet(
      id: int.parse(json['id']),
      name: json['name'],
      balance: double.parse(json['balance']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id.toString(),
      'name': name,
      'balance': balance.toString(),
    };
  }
}

class PayOnStreetPage extends StatelessWidget {
 @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('10:42'),
        centerTitle: true,
        actions: [
          Icon(Icons.flash_on),
          SizedBox(width: 16),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            SizedBox(height: 20),
            Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.black, width: 3),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Center(
                child: Icon(
                  Icons.crop_free,
                  size: 150,
                  color: Colors.black,
                ),
              ),
            ),
            SizedBox(height: 20),
            Text(
              'Silakan scan untuk membayar\nParkir On Street',
              style: TextStyle(fontSize: 16),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 20),
            InformationTable(),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.local_parking),
            label: 'Valet',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.payment),
            label: 'Pay',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.account_balance_wallet),
            label: 'Wallet',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.account_circle),
            label: 'Account',
          ),
        ],
      ),
    );
  }
}

class InformationTable extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Table(
      columnWidths: {
        0: FlexColumnWidth(1),
        1: FlexColumnWidth(2),
      },
      children: [
        TableRow(
          children: [
            TableCell(
                child: Text('Lokasi',
                    style: TextStyle(fontWeight: FontWeight.bold))),
            TableCell(child: Text('Blok M Plaza XXI')),
          ],
        ),
        TableRow(
          children: [
            TableCell(
                child: Text('Jenis Kendaraan',
                    style: TextStyle(fontWeight: FontWeight.bold))),
            TableCell(child: Text('Mobil')),
          ],
        ),
        TableRow(
          children: [
            TableCell(
                child: Text('Tarif',
                    style: TextStyle(fontWeight: FontWeight.bold))),
            TableCell(child: Text('Rp. 5.000/1jam')),
          ],
        ),
        TableRow(
          children: [
            TableCell(
                child: Text('Jam Masuk',
                    style: TextStyle(fontWeight: FontWeight.bold))),
            TableCell(child: Text('18:00')),
          ],
        ),
        TableRow(
          children: [
            TableCell(
                child: Text('Jam Keluar',
                    style: TextStyle(fontWeight: FontWeight.bold))),
            TableCell(child: Text('20:00')),
          ],
        ),
        TableRow(
          children: [
            TableCell(
                child: Text('Total Biaya',
                    style: TextStyle(fontWeight: FontWeight.bold))),
            TableCell(child: Text('Rp. 10.000')),
          ],
        ),
      ],
    );
  }
}

