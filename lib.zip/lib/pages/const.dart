import 'package:flutter/material.dart';

//background color untuk seluruh app
var backgroundColor = Colors.grey;
