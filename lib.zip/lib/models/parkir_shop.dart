import 'package:flutter/material.dart';
import 'parkir.dart';

class ParkirShop extends ChangeNotifier {
  //Tempat Parkir
  final List<Parkir> _shop = [
    Parkir(
      name: 'GBK', 
      price: "4000", 
      imagePath: "lib/images/gbk.png",
      ),
    Parkir(
      name: 'Bundaran HI', 
      price: "5000", 
      imagePath: "lib/images/hi.png",
      ),
    Parkir(
      name: 'Monas', 
      price: "6000", 
      imagePath: "lib/images/monas.png",
      ),
          Parkir(
      name: 'Ragunan', 
      price: "7000", 
      imagePath: "lib/images/ragunan.png",
      ),
  ];

  //User cart
  List<Parkir> _userCart = [];

  //Get Parkir List
  List<Parkir> get parkirShop => _shop;

  //get User Cart
  List<Parkir> get userCart => _userCart;

  //add item to cart
  void addItemToCart(Parkir parkir){
    _userCart.add(parkir);
    notifyListeners();
  }

  //remove item from cart
  void removeItemFromCart(Parkir parkir){
    _userCart.remove(parkir);
    notifyListeners();
  }
}