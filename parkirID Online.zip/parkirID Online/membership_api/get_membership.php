<?php
header("Content-Type: application/json; charset=UTF-8");

$servername = "localhost:3306";
$username = "sihy5111_parkir"; // change to your MySQL username
$password = "waduhparkir"; // change to your MySQL password
$dbname = "sihy5111_parkirid_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

$sql = "SELECT id, location, plate_number FROM memberships";
$result = $conn->query($sql);

$memberships = [];
while ($row = $result->fetch_assoc()) {
    $memberships[] = $row;
}

echo json_encode($memberships);

$conn->close();
?>
