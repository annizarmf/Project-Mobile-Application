<?php
header("Content-Type: application/x-www-form-urlencoded; charset=UTF-8");

$servername = "localhost:3306";
$username = "sihy5111_parkir"; // change to your MySQL username
$password = "waduhparkir"; // change to your MySQL password
$dbname = "sihy5111_parkirid_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$location = $_POST['location'];
$plate_number = $_POST['plate_number'];

$sql = "INSERT INTO memberships (location, plate_number) VALUES (?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $location, $plate_number);

if ($stmt->execute()) {
    echo "Membership created successfully";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
