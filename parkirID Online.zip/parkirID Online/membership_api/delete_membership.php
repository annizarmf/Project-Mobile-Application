<?php
header("Content-Type: application/x-www-form-urlencoded; charset=UTF-8");

$servername = "localhost:3306";
$username = "sihy5111_parkir"; // change to your MySQL username
$password = "waduhparkir"; // change to your MySQL password
$dbname = "sihy5111_parkirid_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = $_POST['id'];

$sql = "DELETE FROM memberships WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo "Membership deleted successfully";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
