<?php
include 'db.php';

header('Content-Type: application/json');

// Get the posted data.
$postData = file_get_contents("php://input");
$request = json_decode($postData);

// Ensure data is not empty
if (!isset($request->email) || !isset($request->password)) {
    echo json_encode(["message" => "Invalid input"]);
    exit;
}

// Extract the data.
$email = $request->email;
$password = $request->password;

// Insert the data into the database.
$sql = "INSERT INTO users (email, password) VALUES ('$email', '$password')";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["message" => "User registered successfully"]);
} else {
    echo json_encode(["message" => "Error: " . $sql . "<br>" . $conn->error]);
}

$conn->close();
?>
