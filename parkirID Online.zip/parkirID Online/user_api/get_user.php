<?php
include 'db.php';

header('Content-Type: application/json');

// Get the posted data.
$postData = file_get_contents("php://input");
$request = json_decode($postData);

// Ensure data is not empty
if (!isset($request->email)) {
    echo json_encode(["message" => "Invalid input"]);
    exit;
}

// Extract the data.
$email = $request->email;

// Fetch user details from the database.
$sql = "SELECT email FROM users WHERE email='$email'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo json_encode(["email" => $row['email']]);
} else {
    echo json_encode(["message" => "User not found"]);
}

$conn->close();
?>
