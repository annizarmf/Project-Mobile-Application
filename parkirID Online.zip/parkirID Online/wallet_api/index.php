<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, GET, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$servername = "localhost:3306";
$username = "sihy5111_parkir"; // change to your MySQL username
$password = "waduhparkir"; // change to your MySQL password
$dbname = "sihy5111_parkirid_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$method = $_SERVER['REQUEST_METHOD'];

switch($method) {
    case 'GET':
        $sql = "SELECT * FROM wallets";
        $result = $conn->query($sql);
        $wallets = array();

        while($row = $result->fetch_assoc()) {
            $wallets[] = $row;
        }

        echo json_encode($wallets);
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"));
        $name = $data->name;
        $balance = $data->balance;

        $sql = "INSERT INTO wallets (name, balance) VALUES ('$name', $balance)";

        if ($conn->query($sql) === TRUE) {
            echo json_encode(array("message" => "Wallet created successfully"));
        } else {
            echo json_encode(array("message" => "Error: " . $conn->error));
        }
        break;

    case 'PUT':
        $data = json_decode(file_get_contents("php://input"));
        $id = $data->id;
        $name = $data->name;
        $balance = $data->balance;

        $sql = "UPDATE wallets SET name='$name', balance=$balance WHERE id=$id";

        if ($conn->query($sql) === TRUE) {
            echo json_encode(array("message" => "Wallet updated successfully"));
        } else {
            echo json_encode(array("message" => "Error: " . $conn->error));
        }
        break;

    case 'DELETE':
        $data = json_decode(file_get_contents("php://input"));
        $id = $data->id;

        $sql = "DELETE FROM wallets WHERE id=$id";

        if ($conn->query($sql) === TRUE) {
            echo json_encode(array("message" => "Wallet deleted successfully"));
        } else {
            echo json_encode(array("message" => "Error: " . $conn->error));
        }
        break;

    default:
        echo json_encode(array("message" => "Invalid request method"));
        break;
}

$conn->close();
?>
