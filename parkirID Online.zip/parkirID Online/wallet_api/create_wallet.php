<?php
header('Content-Type: application/json');
error_reporting(0); // Disable error reporting
ini_set('display_errors', 0);

// Your database connection and logic here...

$servername = "localhost:3306";
$username = "sihy5111_parkir"; // change to your MySQL username
$password = "waduhparkir"; // change to your MySQL password
$dbname = "sihy5111_parkirid_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$name = $_POST['name'];
$balance = $_POST['balance'];

$sql = "INSERT INTO wallets (name, balance) VALUES ('$name', '$balance')";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
