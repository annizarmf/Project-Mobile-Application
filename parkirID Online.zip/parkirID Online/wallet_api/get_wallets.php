<?php
header('Content-Type: application/json');
error_reporting(0); // Disable error reporting
ini_set('display_errors', 0);

// Your database connection and logic here...

$servername = "localhost:3306";
$username = "sihy5111_parkir"; // change to your MySQL username
$password = "waduhparkir"; // change to your MySQL password
$dbname = "sihy5111_parkirid_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT id, name, balance FROM wallets";
$result = $conn->query($sql);

$wallets = array();
while($row = $result->fetch_assoc()) {
  $wallets[] = $row;
}

echo json_encode($wallets);

$conn->close();
?>
